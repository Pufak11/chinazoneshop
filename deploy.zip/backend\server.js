const express = require('express');
const cors = require('cors');
const axios = require('axios');
require('dotenv').config();

const app = express();
app.use(cors());
app.use(express.json());

// Настройки СДЭК
const CDEK_ACCOUNT = process.env.CDEK_ACCOUNT;
const CDEK_SECURE_PASSWORD = process.env.CDEK_SECURE_PASSWORD;
const CDEK_API_URL = process.env.CDEK_API_URL || 'https://api.edu.cdek.ru/v2';

// Настройки Telegram Bot для уведомлений администраторов
const TELEGRAM_BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN;
const TELEGRAM_ADMIN_IDS = process.env.TELEGRAM_ADMIN_IDS 
  ? process.env.TELEGRAM_ADMIN_IDS.split(',').map(id => id.trim())
  : [];

let cdekAccessToken = '';

// Функция для получения токена
async function getCdekToken() {
  try {
    console.log('🔑 Получаю токен СДЭК...');
    
    const response = await axios.post(`${CDEK_API_URL}/oauth/token`, 
      `grant_type=client_credentials&client_id=${CDEK_ACCOUNT}&client_secret=${CDEK_SECURE_PASSWORD}`,
      {
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
        }
      }
    );
    
    cdekAccessToken = response.data.access_token;
    console.log('✅ Токен СДЭК получен');
    
    return cdekAccessToken;
  } catch (error) {
    console.error('❌ Ошибка получения токена СДЭК:', error.response?.data || error.message);
    throw error;
  }
}

// ==================== API ЭНДПОИНТЫ ====================

// 1. Получение городов по названию
app.get('/api/cdek/cities', async (req, res) => {
  try {
    const { search } = req.query;
    
    if (!search || search.length < 2) {
      return res.json([]);
    }
    
    const response = await axios.get(`${CDEK_API_URL}/location/cities`, {
      headers: {
        'Authorization': `Bearer ${cdekAccessToken}`
      },
      params: {
        city: search,
        size: 20
      }
    });
    
    console.log(`🏙️ Найдено городов: ${response.data.length} по запросу "${search}"`);
    res.json(response.data);
  } catch (error) {
    console.error('Ошибка при поиске городов:', error.response?.data || error.message);
    res.status(500).json({ 
      error: 'Ошибка поиска городов',
      details: error.response?.data || error.message 
    });
  }
});

// 2. Расчет стоимости доставки (ПОПРАВЛЕННЫЙ!)
app.post('/api/cdek/calculate', async (req, res) => {
  try {
    const { fromLocation, toLocation, weight = 500, dimensions = {} } = req.body;
    
    console.log('📦 Расчет доставки:', { fromLocation, toLocation, weight });
    
    if (!fromLocation || !toLocation) {
      return res.status(400).json({ error: 'Не указаны города отправления и назначения' });
    }
    
    // Коды городов из запроса
    const fromCityCode = parseInt(fromLocation.code);
    const toCityCode = parseInt(toLocation.code);
    
    // Данные для расчета (стандартная коробка 30x30x30 см, вес от 500г)
    const { length = 30, width = 30, height = 30 } = dimensions || {};

    const calculationData = {
      type: 1, // 1 - до двери, 2 - до склада
      // Поле date у СДЭК часто вызывает валидационную ошибку `v2_invalid_value_type`.
      // Так как оно необязательное для расчета по тарифу, убираем его и даём СДЭК выбрать дату сам.
      currency: 1, // RUB
      lang: 'rus',
      from_location: {
        code: fromCityCode
      },
      to_location: {
        code: toCityCode
      },
      packages: [
        {
          height: height || 30,  // см
          length: length || 30,  // см
          width: width || 30,   // см
          weight: Math.max(weight, 500)  // минимум 500 грамм
        }
      ],
      services: [], // Доп услуги
      tariff_code: 136 // Тариф "Посылка склад-склад"
    };
    
    console.log('📊 Данные для СДЭК:', JSON.stringify(calculationData, null, 2));
    
    const response = await axios.post(`${CDEK_API_URL}/calculator/tariff`, calculationData, {
      headers: {
        'Authorization': `Bearer ${cdekAccessToken}`,
        'Content-Type': 'application/json'
      }
    });
    
    // Нормализуем ответ под фронтенд (он ожидает total_sum).
    // У СДЭК часто цена лежит в delivery_sum.
    const data = response.data || {};
    const normalized = {
      ...data,
      total_sum: data.total_sum ?? data.delivery_sum
    };

    console.log('💰 Результат расчета:', normalized);
    res.json(normalized);
    
  } catch (error) {
    console.error('❌ Ошибка расчета доставки:', error.response?.data || error.message);
    
    // Возвращаем тестовые данные если API не работает
    const testData = {
      total_sum: 450, // Тестовая стоимость
      delivery_summary: {
        delivery_date: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString()
      },
      currency: 'RUB',
      tariffs: [
        {
          tariff_code: 136,
          tariff_name: 'Посылка склад-склад',
          tariff_description: 'Доставка до пункта выдачи',
          delivery_mode: 4,
          delivery_sum: 450,
          period_min: 3,
          period_max: 7
        }
      ]
    };
    
    console.log('📦 Возвращаю тестовые данные:', testData);
    res.json(testData);
  }
});

// 3. Получение пунктов выдачи в городе (ПОПРАВЛЕННЫЙ!)
app.get('/api/cdek/pickup-points', async (req, res) => {
  try {
    const { cityCode } = req.query;
    
    if (!cityCode) {
      return res.status(400).json({ error: 'Не указан код города' });
    }
    
    console.log(`📍 Получаю ПВЗ для города ${cityCode}`);
    
    const response = await axios.get(`${CDEK_API_URL}/deliverypoints`, {
      headers: {
        'Authorization': `Bearer ${cdekAccessToken}`
      },
      params: {
        city_code: parseInt(cityCode),
        type: 'PVZ', // Только пункты выдачи
        size: 50,
        country_code: 'RU',
        lang: 'rus'
      }
    });
    
    // Форматируем ответ
    const pickupPoints = response.data.map(point => ({
      id: point.code,
      code: point.code,
      name: point.name,
      address: point.location?.address || 'Адрес не указан',
      city: point.location?.city || '',
      country: point.location?.country_code || 'RU',
      postalCode: point.location?.postal_code || '',
      coordinates: [
        point.location?.latitude || 0,
        point.location?.longitude || 0
      ],
      workTime: point.work_time || 'пн-пт 09:00-20:00, сб-вс 10:00-18:00',
      phone: point.phone || '',
      note: point.note || '',
      type: point.type || 'PVZ',
      weightMin: point.weight_min || 0,
      weightMax: point.weight_max || 30000,
      hasCash: point.have_cashless || true,
      hasCashOnDelivery: point.have_cash || true,
      allowedCod: point.allowed_cod || false,
      nearestStation: point.nearest_station || '',
      site: point.site || '',
      email: point.email || '',
      officeImageList: point.office_image_list || [],
      workTimeList: point.work_time_list || []
    }));
    
    console.log(`✅ Получено ${pickupPoints.length} ПВЗ`);
    res.json(pickupPoints);
    
  } catch (error) {
    console.error('❌ Ошибка получения ПВЗ:', error.response?.data || error.message);
    
    // Тестовые данные для Санкт-Петербурга
    const testPoints = [
      {
        id: 'spb_001',
        code: 'SPB001',
        name: 'ПВЗ СДЭК на Московском',
        address: 'Санкт-Петербург, Московский пр., 100',
        city: 'Санкт-Петербург',
        country: 'RU',
        postalCode: '196084',
        coordinates: [59.89444, 30.26417],
        workTime: 'пн-пт 09:00-20:00, сб 10:00-18:00, вс 10:00-16:00',
        phone: '+7 (812) 123-45-67',
        note: 'Метро Московские ворота',
        type: 'PVZ',
        weightMin: 0,
        weightMax: 30000,
        hasCash: true,
        hasCashOnDelivery: true,
        allowedCod: true
      },
      {
        id: 'spb_002',
        code: 'SPB002',
        name: 'ПВЗ СДЭК Центральный',
        address: 'Санкт-Петербург, Невский пр., 50',
        city: 'Санкт-Петербург',
        country: 'RU',
        postalCode: '191186',
        coordinates: [59.93583, 30.32586],
        workTime: 'пн-вс 08:00-22:00',
        phone: '+7 (812) 234-56-78',
        note: 'Метро Гостиный двор',
        type: 'PVZ',
        weightMin: 0,
        weightMax: 30000,
        hasCash: true,
        hasCashOnDelivery: true,
        allowedCod: true
      },
      {
        id: 'spb_003',
        code: 'SPB003',
        name: 'ПВЗ СДЭК на Васильевском',
        address: 'Санкт-Петербург, Средний пр. В.О., 30',
        city: 'Санкт-Петербург',
        country: 'RU',
        postalCode: '199004',
        coordinates: [59.94111, 30.28111],
        workTime: 'пн-пт 10:00-21:00, сб-вс 11:00-19:00',
        phone: '+7 (812) 345-67-89',
        note: 'Метро Василеостровская',
        type: 'PVZ',
        weightMin: 0,
        weightMax: 30000,
        hasCash: true,
        hasCashOnDelivery: true,
        allowedCod: true
      },
      {
        id: 'spb_004',
        code: 'SPB004',
        name: 'ПВЗ СДЭК Приморский',
        address: 'Санкт-Петербург, ул. Савушкина, 10',
        city: 'Санкт-Петербург',
        country: 'RU',
        postalCode: '197183',
        coordinates: [59.98528, 30.21306],
        workTime: 'пн-пт 09:00-20:00, сб 10:00-18:00',
        phone: '+7 (812) 456-78-90',
        note: 'Метро Старая Деревня',
        type: 'PVZ',
        weightMin: 0,
        weightMax: 30000,
        hasCash: true,
        hasCashOnDelivery: true,
        allowedCod: true
      },
      {
        id: 'spb_005',
        code: 'SPB005',
        name: 'ПВЗ СДЭК Фрунзенский',
        address: 'Санкт-Петербург, Бухарестская ул., 40',
        city: 'Санкт-Петербург',
        country: 'RU',
        postalCode: '192283',
        coordinates: [59.85722, 30.38417],
        workTime: 'пн-пт 08:30-21:30, сб-вс 09:00-20:00',
        phone: '+7 (812) 567-89-01',
        note: 'Метро Международная',
        type: 'PVZ',
        weightMin: 0,
        weightMax: 30000,
        hasCash: true,
        hasCashOnDelivery: true,
        allowedCod: true
      }
    ];
    
    console.log(`📦 Возвращаю тестовые ПВЗ: ${testPoints.length} пунктов`);
    res.json(testPoints);
  }
});

// 4. Создание заказа в СДЭК
app.post('/api/cdek/create-order', async (req, res) => {
  try {
    const orderData = req.body;
    
    console.log('📝 Создание заказа в СДЭК:', orderData.orderId);
    
    // Тестовый ответ
    const testResponse = {
      entity: {
        uuid: 'test-uuid-' + Date.now(),
        order_number: orderData.orderId || 'TEST-' + Date.now(),
        status: 'CREATED',
        cdek_number: 'CDEK' + Date.now(),
        delivery_sum: orderData.delivery?.cost || 450,
        payment_sum: orderData.summary?.total || 0,
        recipient_name: orderData.contact?.name || '',
        recipient_phone: orderData.contact?.phone || '',
        delivery_point: orderData.delivery?.point?.code || '',
        tariff_code: 136
      }
    };
    
    console.log('✅ Заказ создан:', testResponse);
    res.json(testResponse);
    
  } catch (error) {
    console.error('❌ Ошибка создания заказа:', error.response?.data || error.message);
    res.status(500).json({ 
      error: 'Ошибка создания заказа',
      details: error.response?.data || error.message 
    });
  }
});

// 5. Отправка уведомлений администраторам о новом заказе
app.post('/api/orders/notify', async (req, res) => {
  try {
    const orderData = req.body;
    
    if (!TELEGRAM_BOT_TOKEN || TELEGRAM_ADMIN_IDS.length === 0) {
      console.warn('⚠️ Telegram Bot не настроен. Пропускаем отправку уведомлений.');
      return res.json({ 
        success: false, 
        message: 'Telegram Bot не настроен' 
      });
    }

    // Формируем сообщение для администраторов
    const formatOrderMessage = (order) => {
      const itemsList = order.items.map(item => 
        `  • ${item.name} × ${item.quantity} = ${item.total.toLocaleString()} ₽`
      ).join('\n');
      
      const deliveryInfo = order.delivery?.method === 'pickup'
        ? `📍 ПВЗ: ${order.delivery.point?.name || 'Не указан'}\n   Адрес: ${order.delivery.point?.address || 'Не указан'}`
        : order.delivery?.method === 'store'
        ? `🏪 Самовывоз из магазина\n   ${order.delivery.store?.address || 'пр. Обуховской Обороны, 209'}`
        : 'Не указан';
      
      const userLink = order.telegramUser?.id
        ? `[${order.telegramUser.firstName || 'Пользователь'}](tg://user?id=${order.telegramUser.id})`
        : order.contact?.name || 'Не указан';
      
      const userInfo = order.telegramUser
        ? `👤 Пользователь: ${userLink}\n   Username: @${order.telegramUser.username || 'не указан'}`
        : `👤 Клиент: ${order.contact?.name || 'Не указан'}`;

      return `🛒 *Новый заказ #${order.orderId}*

${userInfo}
📞 Телефон: ${order.contact?.phone || 'Не указан'}
📧 Email: ${order.contact?.email || 'Не указан'}

📦 *Товары:*
${itemsList}

💰 *Итого:*
  Товары: ${order.summary.itemsTotal.toLocaleString()} ₽
  Доставка: ${order.summary.deliveryCost.toLocaleString()} ₽
  *Всего: ${order.summary.total.toLocaleString()} ₽*

🚚 *Доставка:*
${deliveryInfo}
${order.delivery?.city ? `   Город: ${order.delivery.city.name}` : ''}
${order.delivery?.deliveryTime ? `   Срок: ${order.delivery.deliveryTime}` : ''}

${order.contact?.comment ? `💬 Комментарий: ${order.contact.comment}` : ''}

⏰ ${new Date(order.timestamp).toLocaleString('ru-RU')}`;
    };

    const message = formatOrderMessage(orderData);
    
    // Отправляем уведомления всем администраторам
    const sendPromises = TELEGRAM_ADMIN_IDS.map(async (adminId) => {
      try {
        const response = await axios.post(
          `https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`,
          {
            chat_id: adminId,
            text: message,
            parse_mode: 'Markdown',
            disable_web_page_preview: true
          }
        );
        console.log(`✅ Уведомление отправлено администратору ${adminId}`);
        return { adminId, success: true };
      } catch (error) {
        console.error(`❌ Ошибка отправки администратору ${adminId}:`, error.response?.data || error.message);
        return { adminId, success: false, error: error.message };
      }
    });

    const results = await Promise.all(sendPromises);
    const successCount = results.filter(r => r.success).length;

    res.json({
      success: successCount > 0,
      sent: successCount,
      total: TELEGRAM_ADMIN_IDS.length,
      results
    });

  } catch (error) {
    console.error('❌ Ошибка отправки уведомлений:', error);
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

// 6. Проверка здоровья API
app.get('/api/health', (req, res) => {
  res.json({ 
    status: 'OK', 
    timestamp: new Date().toISOString(),
    service: 'CDEK Integration API',
    version: '1.0.0',
    cdekToken: cdekAccessToken ? 'Получен' : 'Не получен',
    telegramBot: TELEGRAM_BOT_TOKEN ? 'Настроен' : 'Не настроен',
    adminCount: TELEGRAM_ADMIN_IDS.length,
    endpoints: [
      '/api/cdek/cities - поиск городов',
      '/api/cdek/calculate - расчет доставки',
      '/api/cdek/pickup-points - пункты выдачи',
      '/api/cdek/create-order - создание заказа',
      '/api/orders/notify - уведомления о заказах'
    ]
  });
});

// Запуск сервера
const PORT = process.env.PORT || 3001;

app.listen(PORT, async () => {
  console.log(`🚀 Сервер запущен на http://localhost:${PORT}`);
  console.log(`📡 CDEK API: ${CDEK_API_URL}`);
  
  try {
    await getCdekToken();
    
    // Обновляем токен каждые 50 минут
    setInterval(getCdekToken, 50 * 60 * 1000);
    
  } catch (error) {
    console.error('⚠️ Не удалось получить токен СДЭК. Работаем в тестовом режиме.');
    console.log('ℹ️ Проверьте CDEK_ACCOUNT и CDEK_SECURE_PASSWORD в файле .env');
  }
});