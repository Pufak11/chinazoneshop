# Настройка Telegram уведомлений для администраторов

## Шаг 1: Создание Telegram бота

1. Откройте Telegram и найдите бота [@BotFather](https://t.me/BotFather)
2. Отправьте команду `/newbot`
3. Следуйте инструкциям и создайте бота
4. Сохраните **токен бота** (выглядит как `123456789:ABCdefGHIjklMNOpqrsTUVwxyz`)

## Шаг 2: Получение Chat ID администраторов

### Способ 1: Через бота @userinfobot
1. Найдите бота [@userinfobot](https://t.me/userinfobot) в Telegram
2. Начните диалог с ботом
3. Бот покажет ваш `Id` - это и есть ваш Chat ID

### Способ 2: Через вашего бота
1. Начните диалог с вашим ботом
2. Отправьте любое сообщение боту
3. Откройте в браузере: `https://api.telegram.org/bot<ВАШ_ТОКЕН>/getUpdates`
4. Найдите в ответе поле `"chat":{"id":123456789}` - это Chat ID

## Шаг 3: Настройка .env файла

Создайте или обновите файл `backend/.env`:

```env
# Telegram Bot настройки
TELEGRAM_BOT_TOKEN=123456789:ABCdefGHIjklMNOpqrsTUVwxyz
TELEGRAM_ADMIN_IDS=123456789,987654321
```

Где:
- `TELEGRAM_BOT_TOKEN` - токен вашего бота от BotFather
- `TELEGRAM_ADMIN_IDS` - Chat ID администраторов через запятую (без пробелов)

## Пример .env файла

```env
# СДЭК
CDEK_ACCOUNT=your_cdek_account
CDEK_SECURE_PASSWORD=your_cdek_password
CDEK_API_URL=https://api.cdek.ru/v2

# Telegram
TELEGRAM_BOT_TOKEN=123456789:ABCdefGHIjklMNOpqrsTUVwxyz
TELEGRAM_ADMIN_IDS=123456789,987654321

# Server
PORT=3001
```

## Проверка работы

После настройки перезапустите backend сервер и проверьте:

```bash
curl http://localhost:3001/api/health
```

В ответе должно быть:
```json
{
  "telegramBot": "Настроен",
  "adminCount": 2
}
```

## Формат уведомления

Когда клиент оформит заказ, администраторы получат сообщение в Telegram с:
- Номером заказа
- Ссылкой на пользователя Telegram (кликабельная)
- Данными клиента (имя, телефон, email)
- Списком товаров
- Информацией о доставке
- Итоговой суммой

## Важно

- Бот должен быть запущен (начать диалог с ботом хотя бы раз)
- Chat ID должны быть корректными
- Токен бота должен быть действительным
